    const ICONS = {
      info: "fa-info",
      success: "fa-check",
      error: "fa-xmark",
      warning: "fa-exclamation",
      server: "fa-server"
    };

window.addEventListener("message", (event) => {
    const data = event.data;
    if (data.action === "Show") {
        const msg = data.Message?.text || data.Message || "Undefined!";
        showNotification(msg, data.Type, data.Duration, data.Position);
    }
});

function showNotification(message, type = "info", duration = 3000, position = "top-left") {
  const container = document.getElementById("notifications");

  const notif = document.createElement("div");
  notif.className = `notification ${type} ${position}`;

  let msgText = typeof message === "object" ? message.text : message;

  notif.innerHTML = `
    <i class="fa-solid ${ICONS[type] || "fa-info"}"></i>
    <span>${msgText}</span>
  `;

  container.appendChild(notif);

  setTimeout(() => notif.classList.add("show"), 50);

  setTimeout(() => {
    notif.classList.remove("show");
    setTimeout(() => notif.remove(), 500);
  }, duration);
}
