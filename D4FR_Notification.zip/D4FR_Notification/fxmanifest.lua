fx_version "cerulean"
game "gta5"

version "1.2.0"
author "D4FR"

ui_page "html/index.html"
files { "html/**" }

shared_scripts { "configs.lua" }
client_scripts { "cl_main.lua" }