RegisterNetEvent("D4FR_Notification:Show")
AddEventHandler("D4FR_Notification:Show", function(message, type, duration, position)
    SendNUIMessage({
        action = "Show",
        Message = { text = message },
        Type = type,
        Duration = duration,
        Position = position
    })
end)

D4 = D4 or {}

D4.CreateNotification = function (message, type, duration, position)
    TriggerEvent("D4FR_Notification:Show", message, type, duration, position)
end

if D4.Debug then
    CreateThread(function ()
        print("[DEBUG] : Debug mode is on!")
        print("[VERSION] : 1.2.0")

        RegisterCommand("notify:debug", function()
            TriggerEvent("D4FR_Notification:Show", "TEST TEST TEST TEST TEST TEST", "warning", 3000, "top-right")
            print("[DEBUG] : Triggered!")
        end)
    end)
else
    CreateThread(function()
        print("[DEBUG] : Debug mode is off!")
    end)
end